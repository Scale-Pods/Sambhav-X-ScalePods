# ScalePods - READ-ONLY: ask TallyPrime for its Day Book, a few days at a time (gentle on a live multi-user Tally).
# It only ASKS Tally for data. It changes nothing in Tally and installs nothing.
# Run on the Tally PC with Sambhav's company loaded:
#     powershell -ExecutionPolicy Bypass -File "E:\Export\tally-daybook.ps1" -Port 9001 -Out "E:\Export\daybook-sambhav"
# Default: 1 to 7 September 2026 (one small test week). Once that works, ask for more with -From and -To (yyyymmdd).
param([int]$Port = 9001, [string]$Out = "E:\Export\daybook-sambhav", [string]$From = "20260901", [string]$To = "20260907", [int]$ChunkDays = 3)

New-Item -ItemType Directory -Force -Path $Out | Out-Null
$base = "http://localhost:$Port"
$log = Join-Path $Out "daybook-log.txt"
"ScalePods Tally day book, $(Get-Date -Format s), port $Port, $From to $To, $ChunkDays days at a time" | Out-File $log

function Say($m) { Write-Host $m; $m | Out-File $log -Append }

$start = [datetime]::ParseExact($From, "yyyyMMdd", $null)
$end   = [datetime]::ParseExact($To, "yyyyMMdd", $null)
$d = $start
while ($d -le $end) {
    $e = $d.AddDays($ChunkDays - 1); if ($e -gt $end) { $e = $end }
    $a = $d.ToString("yyyyMMdd"); $b = $e.ToString("yyyyMMdd")
    $xml = "<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Data</TYPE><ID>Day Book</ID></HEADER><BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>`$`$SysName:XML</SVEXPORTFORMAT><SVFROMDATE>$a</SVFROMDATE><SVTODATE>$b</SVTODATE></STATICVARIABLES></DESC></BODY></ENVELOPE>"
    $file = Join-Path $Out "daybook-$a-$b.xml"
    $t = Get-Date
    try {
        Invoke-WebRequest -Uri $base -Method Post -Body $xml -ContentType "text/xml" -UseBasicParsing -TimeoutSec 900 -OutFile $file
        Say ("OK    {0}-{1} {2,12:N0} bytes  {3:N0}s" -f $a, $b, (Get-Item $file).Length, ((Get-Date) - $t).TotalSeconds)
    } catch {
        Say ("FAIL  {0}-{1} {2}" -f $a, $b, $_.Exception.Message)
    }
    $d = $e.AddDays(1)
}
Say "Done. Copy the folder $Out back to ScalePods."
